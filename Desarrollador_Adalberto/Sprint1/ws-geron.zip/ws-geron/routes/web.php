<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//HTML5 no funciona aquí
//Route::view('/registro', 'register');

//Formulario de registro de usuarios

Route::view('/home', 'home')->name('home');
Route::view('/otro', 'otro')->name('otro');
Route::view('/register', 'register')->name('register');
Route::view('/login', 'login')->name('login');

//Ruta para procesar registro de usuarios
Route::post('/registrar-usuario', '\App\Http\Controllers\UserController@store')->name('usuario.store');
Route::post('/login-user', '\App\Http\Controllers\UserController@login')->name('usuario.login');
