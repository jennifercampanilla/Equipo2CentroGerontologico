<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
class UserController extends Controller
{
    public function store(Request $request)
    {   
        //@dump($request->all());

        // Valida los datos del formulario
        $request->validate([
            'name' => 'required',
            'telefono' => 'required',
            'email' => 'required|email|unique:users',
            'date_born' => 'required',
        ]);

        

        // Crea un nuevo registro de usuario
        $user= User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'telefono' => $request->input('telefono'),
            'date_born' => $request->input('date_born'),
            $data['servicio1'] = $request->has('servicio1'),
            $data['servicio2'] = $request->has('servicio2'),
            $data['servicio3'] = $request->has('servicio3'),
            'servicio1' => $request->input(true),
            'servicio2' => $request->input(true),
            'servicio3' => $request->input(true),
            
        ]);
        
        
        return redirect()->route('home'); // Corregido para usar route() correctamente
    }

    public function login(Request $request)
{   
    @dump($request->all());
        $this->validate($request, [
            'telefono' => 'required',
        ]);

        $telefono = $request->input('tel');
        
        $user = User::where('telefono', $telefono)->first();

        if ($user) {
            Auth::login($user);
            Log::info();
            //return redirect("{{ route('/home') }}"); // Redirigir después del inicio de sesión exitoso.
            return redirect()->route('otro');
        } else{

        return back()->with('error', 'Número de teléfono no encontrado.');
         }
}
}
