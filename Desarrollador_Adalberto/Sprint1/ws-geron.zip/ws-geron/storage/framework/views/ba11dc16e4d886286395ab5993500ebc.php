<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <title>Bienvenido a mi Formulario</title>
</head>

<body>
    <div class="container-form sign-up">
        <div class="welcome-back">
            <div class="message">
                <h2>Bienvenido al Centro Gerontologico</h2>
                <p>Si ya tienes una cuenta por favor inicia sesión aqui</p>
                <button class="sign-up-btn">Iniciar Sesion</button>
            </div>
        </div>
        <form class="formulario" method="POST" action="<?php echo e(route('usuario.store')); ?>">
        <?php echo csrf_field(); ?>
            <h2 class="create-account">Crear una cuenta</h2>

            <p class="cuenta-gratis">Crear una cuenta gratis</p>
            <input type="text" name="name" placeholder="Nombre">
            <input type="tel" name="telefono" placeholder="Telefono">
            <input type="email" name="email" placeholder="Email">
            
            <input type="date" name="date_born" placeholder="Fecha de nacimiento">

            <label>Cocina<input type="checkbox" name="servicio1" value="cocina"> </label>
            <label>Danza<input type="checkbox" name="servicio2" value="danza"></label>
            <label>Papel nono<input type="checkbox" name="servicio3" value="papel_nono"></label>
            
            
            
                <button type="submit" class="sign-in-btn">Registrarse</button>
        </form>
    </div>
    <div class="container-form sign-in">
        
            <h2 class="create-account">Iniciar Sesion</h2>
            <p class="cuenta-gratis">Ingresa aqui con tu numero de telefono</p>
            <input type="tel" placeholder="Telefono">
            <input type="button" value="Iniciar Sesion">
            <div class="welcome-back">
            <div class="message">
                <h2>Bienvenido de nuevo</h2>
                <p>Si aun no tienes una cuenta por favor registrese aqui</p>
            </div>
        </div>
        
        
    </div>
    <script src="<?php echo e(asset('/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH /home/adalberto/Escritorio/Scrum/ws-geron/resources/views/index.blade.php ENDPATH**/ ?>