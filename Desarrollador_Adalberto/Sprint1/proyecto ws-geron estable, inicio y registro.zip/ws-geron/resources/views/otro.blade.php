<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <div class="background-container"></div>
    <div class="content">
    <div class="container-form sign-in">
        <div class="welcome-back">
            <div class="message">
                <h1>Bienvenido al Centro Gerontológico</h1>
                <br>
                <h3>Si aun no tienes una cuenta, por favor registrese aquí</h3>
                <button class="sign-in-btn">Registrarse</button>
            </div>
        </div>

        
       
    </div>
    </div>
</body>
</html>