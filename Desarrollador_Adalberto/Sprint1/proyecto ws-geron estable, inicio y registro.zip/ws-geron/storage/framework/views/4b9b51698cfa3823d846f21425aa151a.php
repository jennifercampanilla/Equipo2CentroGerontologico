<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="/css/styles.css" />

    <style>
      a,
      button,
      input,
      select,
      h1,
      h2,
      h3,
      h4,
      h5,
      * {
        margin: 0;
        padding: 0;
        border: none;
        text-decoration: none;
        appearance: none;
        background: none;
      }
    </style>
    <title>Document</title>
  </head>
  <body>
    <div class="frame-3">
      <img class="image-6" src="/imgs/logo.jpeg" width="20px" height="20px" "/>
      <div class="bienvenido-al-centro-geronotologico">
        Bienvenido al Centro Geronotologico
      </div>
      <div class="rectangle-43"></div>
      <svg
        class="rectangle-41"
        width="205"
        height="61"
        viewBox="0 0 205 61"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0 20C0 8.95431 8.9543 0 20 0H185C196.046 0 205 8.9543 205 20V41C205 52.0457 196.046 61 185 61H20C8.95431 61 0 52.0457 0 41V20Z"
          fill="#E0EE3B"
        />
      </svg>

      <div
        class="ya-tienes-cuenta-y-quieres-inscribirte-a-un-nuevo-taller-inicia-sesi-n"
      >
        ¿Ya tienes cuenta y quieres inscribirte a un nuevo taller? Inicia sesión
      </div>
      <button type="button" class="iniciar-sesi-n">Iniciar sesión</button>
      <svg
        class="rectangle-42"
        width="205"
        height="61"
        viewBox="0 0 205 61"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0 20C0 8.95431 8.9543 0 20 0H185C196.046 0 205 8.9543 205 20V41C205 52.0457 196.046 61 185 61H20C8.95431 61 0 52.0457 0 41V20Z"
          fill="#971D15"
        />
      </svg>

      
      <button class="registrarse">Registrarse</button>
      <div class="registro-de-adultos-mayores">Registro de adultos mayores</div>
      <div class="talleres-a-los-que-desea-inscribirse">
        Talleres a los que desea inscribirse:
      </div>
      <div class="line-10"></div>
      <div class="line-13"></div>
      <div class="tel-fono">Teléfono</div>
      <div class="correo-electr-nico">Correo electrónico</div>
      <div class="fecha-de-nacimiento">Fecha de nacimiento</div>
      <div class="nombre-completo">Nombre Completo</div>
      <div class="cocina">Cocina</div>
      <div class="papel-nono">Papel nono</div>
      <div class="danza">Danza</div>
      <svg
        class="line-11"
        width="270"
        viewBox="0 0 270 0"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M0 0H270" stroke="black" />
      </svg>

      <div class="line-12"></div>
      <svg
        class="rectangle-44"
        width="13"
        height="81"
        viewBox="0 0 13 81"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M0 0H13V12H0V0Z" fill="white" />
        <path d="M0 0H13V12H0V0Z" fill="white" />
        <path d="M0 68.5H13V80.5H0V68.5Z" fill="white" />
        <path d="M0 33H13V45H0V33Z" fill="white" />
        <path d="M0 33H13V45H0V33Z" fill="white" />
      </svg>
    </div>
  </body>
</html><?php /**PATH /home/adalberto/Escritorio/Scrum/ws-geron/resources/views/register.blade.php ENDPATH**/ ?>